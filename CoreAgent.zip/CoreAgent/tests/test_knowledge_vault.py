"""
CoreAgent-2 — Knowledge Vault Tests
Tests CRUD operations and search.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.documents import Document


def test_vault_collection_crud():
    """Test creating, listing, and deleting collections."""
    from core.knowledge.vault import KnowledgeVault
    v = KnowledgeVault()

    # Create
    v.get_or_create_collection("test_collection")
    cols = v.list_collections()
    assert "test_collection" in cols, f"Expected 'test_collection' in {cols}"

    # Info
    info = v.get_collection_info("test_collection")
    assert info.get("name") == "test_collection"
    assert info.get("count") == 0

    # Delete
    assert v.delete_collection("test_collection") is True
    print("✅ Collection CRUD works.")


def test_vault_add_and_search():
    """Test adding documents and searching."""
    from core.knowledge.vault import KnowledgeVault
    v = KnowledgeVault()

    docs = [
        Document(page_content="Python is a programming language.", metadata={"source": "test"}),
        Document(page_content="Machine learning uses neural networks.", metadata={"source": "test"}),
    ]

    v.add_documents("test_search_col", docs)

    # Search
    results = v.search("programming language", collection_name="test_search_col", threshold=2.0)
    assert len(results) > 0, "Expected at least one search result"

    # Cleanup
    v.delete_collection("test_search_col")
    print("✅ Add and search works.")


if __name__ == "__main__":
    test_vault_collection_crud()
    test_vault_add_and_search()
    print("\n🎉 All Knowledge Vault tests passed!")
