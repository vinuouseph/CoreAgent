"""
CoreAgent-2 — Graph Integration Tests
Tests routing, Self-RAG loop, and HITL interrupt.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from langchain_core.messages import HumanMessage


def test_graph_builds():
    """Test that the graph compiles without errors."""
    from core.graph.orchestrator import core_agent_graph
    assert core_agent_graph is not None
    print("✅ Graph builds successfully.")


def test_state_schema():
    """Test that AgentState fields are defined correctly."""
    from core.graph.state import AgentState
    annotations = AgentState.__annotations__
    assert "messages" in annotations
    assert "route" in annotations
    assert "query" in annotations
    assert "documents" in annotations
    assert "trace" in annotations
    assert "requires_approval" in annotations
    print("✅ AgentState schema is valid.")


def test_conditional_edges():
    """Test that conditional edge functions return valid node names."""
    from core.graph.edges.conditionals import route_query, grade_documents

    # Test route_query
    assert route_query({"route": "search"}) == "retriever"
    assert route_query({"route": "tool_call"}) == "tool_executor"
    assert route_query({"route": "respond"}) == "responder"
    assert route_query({}) == "responder"  # default fallback

    # Test grade_documents
    assert grade_documents({"docs_relevant": True}) == "generator"
    assert grade_documents({"docs_relevant": False, "retry_count": 0}) == "rewriter"
    assert grade_documents({"docs_relevant": False, "retry_count": 10}) == "generator"  # exhausted retries

    print("✅ Conditional edges work correctly.")


def test_tool_registry():
    """Test that tools can be registered and retrieved."""
    from core.tools.registry import ToolRegistry
    from core.tools.knowledge_search import knowledge_search
    from core.tools.web_search import web_search

    reg = ToolRegistry()
    reg.register(knowledge_search)
    reg.register(web_search, requires_approval=True)

    assert reg.get_tool_by_name("knowledge_search") is not None
    assert reg.get_tool_by_name("web_search") is not None
    assert reg.get_tool_by_name("nonexistent") is None
    assert len(reg.get_all_tools()) == 2
    assert web_search.metadata["requires_approval"] is True

    print("✅ Tool registry works correctly.")


if __name__ == "__main__":
    test_graph_builds()
    test_state_schema()
    test_conditional_edges()
    test_tool_registry()
    print("\n🎉 All tests passed!")
